package project;
import java.util.Scanner;

public class Blush extends Face {

    private String color;
    private double price;
    private String type;
    private int choice ;
    private int number ;

    public int getChoice() {
        return choice;
    }

    public int getNumber() {
        return number;
    }
    public Scanner input = new Scanner(System.in);

    public Blush(String color, double price, String type) {
       
        this.color = color;
        this.price = price;
        this.type = type;
    }
    
    public Blush(){}
    
    public String getColor() {
        return color;
    }

    public double getPrice() {
        return price;
    }

    public String getType() {
        return type;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setType(String type) {
        this.type = type;
    }


     @Override
    public void choice() {
        System.out.println("\u001B[35m" + "\t\t Blushes" + "\u001B[47m");
        System.out.println("FIND YOUR FLUSH. SHOP BLUSH POWDERS, PALETTES AND CREAMS. ");
        System.out.println("__________________________________________________");
        System.out.println(" 1.Gorgeous Matte Blush 26.25 SAR \n 2.Creamy Whipped Blush 35.62 SAR " );
       do{
         choice = input.nextInt();
         if(choice != 1 && choice != 2)
              System.out.println("\u001B[31m"+"invalid input please try again\n" +  "select 1 or 2" +"\033[0m" );
        }while(choice != 1 && choice != 2);
        selectColor();
        System.out.print("\u001B[35m" + "please enter how many product would you like to add:" + "\u001B[42m"+"\033[0m" );
         number = input.nextInt();
        //price += cost(choice , number);
        System.out.println("__________________________________________________");
    }

   @Override
    public void selectColor() {
        
        boolean i = true ;
        System.out.println("\u001B[35m" + "************** Select Color**************" + "\u001B[35m");
        System.out.println("01 Nude \n02 Baby doll \n03 Showgirl ");
       
         while(i){
        
            int num = input.nextInt();
        switch (num) {
            case 01:
                setColor("Nude");i = false;
                break;

            case 02:
                 setColor("Baby doll"); i = false;
                break;

            case 03:
                setColor("Showgirl");i = false;
                break;
            default:
                System.out.println("invalid input please try again\n" + "\u001B[31m"+ "select from 1 to 4" +"\033[0m" );
        } }
     
    }

     @Override
    public double cost() {
        
              choice();
        switch (choice) {
            case 1:
                price = 26.25 * number;
                setType("Gorgeous Matte Blush");
                break;
            case 2:
                price = 35.62 * number;
                setType("Creamy Whipped Blush");
                break;
            default:
                price = 0;
        }
        return price = price + (price * Payable.TAX);
    }

    @Override
    public String toString( ){
     
        return  "type = " + getType() +"\nColor = " + getColor() + "\nprice = " + getPrice() + " SAR";                                                                                                            
    }

    
}

