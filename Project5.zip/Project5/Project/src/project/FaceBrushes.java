package project;
import java.util.Scanner;

public class FaceBrushes extends Brush {

    public Scanner input = new Scanner(System.in);
    private double cost ;
    private String type;
    private int choice ;
    private int number ;

    public int getChoice() {
        return choice;
    }

    public int getNumber() {
        return number;
    }
    public FaceBrushes() {
        
    }

    
    @Override
    public void choice() {
     
        System.out.println("\u001B[35m" + "************** Face Brushes **************" +"\033[0m");
        System.out.println("1- Highlighting Brush\n"
                + "2- Pro Buffing Brush\n"
                + "3- liquid Foundation Brush  \n"
                + "4- Multi-Purpose Face Brush \n"
                + "5- Loose Powder Brush\n");
                  
       System.out.println("\u001B[35m" +"Enter The number of The Brush type you Choice" +"\033[0m");
           do{
         choice = input.nextInt();
         if(choice != 1 && choice != 2 && choice != 3 && choice != 4 && choice != 5 )
              System.out.println("\u001B[31m"+"invalid input please try again\n" +  "select 1 to 5" +"\033[0m" );
        }while(choice != 1 && choice != 2 && choice != 3 && choice != 4 && choice != 5 );
           System.out.println("Enter number you want:" );
         number = input.nextInt();
      
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    

    @Override
    public double cost() {
       
         choice();
        switch (choice) {
            case 1:
                cost = 57;
                setType("Highlighting Brush");
                break;

            case 2:
                cost = 56;
                 setType("Pro Buffing Brush");
                break;
            case 3:
                cost = 52;
                 setType("liquid Foundation Brush");
                break;
            case 4:
                cost = 63;
                 setType("Multi-Purpose Face Brush");
                break;
            case 5:
                cost = 50;
                 setType("Loose Powder Brush");
                break;
            default:
                 System.out.println("This Item is not Available");
        }
        return cost = cost + (cost*Payable.TAX);  

    }
    @Override
    public String toString( ){
        return  "type = " + getType() + "\nprice = " + getCost() + " SAR";
                                                                                                                          
    }

}
