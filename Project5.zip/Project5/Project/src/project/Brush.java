package project;
public abstract class Brush extends Product {

     public Brush() {
        
    }
     @Override
    public abstract void choice();

    @Override
    public String toString() {
        return "Brush{" + '}';
    }

    
    
    
    }
