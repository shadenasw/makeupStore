package project;
import java.util.Scanner;
public class Eyeshadow extends Eye {
    
    public Scanner read = new Scanner(System.in);
    private double price ;
    private String type ;
    private int choice ;
    private int number ;

    public int getChoice() {
        return choice;
    }

    public int getNumber() {
        return number;
    }
    public Eyeshadow() {
       
    }

    public Eyeshadow(double price, String type) {
      
        this.price = price;
        this.type = type;
    }
    
  
    @Override
    public void choice(){
       
        System.out.println("\u001B[35m" + "************** EyeShadow **************" +"\033[0m");
        System.out.println(
                    "1: Gimmy Stars Shadow Palette 112.50 SAR " 
                + "\n2: Ultimate Queen Shadow 131.25 SAR "
                + "\n3: Lid Lingerie Shadow Palette 37.50 SAR "
                + "\n4: Single Eyeshadow 16.88 SAR"
                + "\n5: Metal Play Pigment Palette 37.50 SAR");
                   
                System.out.println("\u001B[35m" + "Please choose the type of Eyeshadow you want: " +"\033[0m");
          do{
         choice = read.nextInt();
         if(choice != 1 && choice != 2 && choice != 3 && choice != 4 && choice != 5 )
              System.out.println("\u001B[31m"+"invalid input please try again\n" +  "select 1 to 5" +"\033[0m" );
        }while(choice != 1 && choice != 2 && choice != 3 && choice != 4 && choice != 5 );
            System.out.println("please enter number you want:" );
         number = read.nextInt();
        
        }

    public double getPrice() {
        return price;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
        
    
  @Override
    public double cost() {
        choice();
        switch(choice){
            case 1 : price = 112.50 * number ; 
              setType("Gimmy Stars Shadow Palette")  ; break;
            case 2 : price = 131.25 * number ; 
              setType("Ultimate Queen Shadow")  ; break;
            case 3 : price = 37.50 * number ; 
              setType("Lid Lingerie Shadow Palette")  ; break;
            case 4 : price = 16.88 * number ; 
              setType("Single Eyeshadow")  ; break;
            case 5 : price = 37.50 * number ; 
              setType("Metal Play Pigment Palette")  ; break;
            default: 
                price = 0;
       }      
        
       return price = price + (price*Payable.TAX);  
   
}

   @Override
    public String toString( ){
       
        return  "type = " + getType() + "\nprice = " + getPrice() + " SAR";
                                                                                                                          
    }
   
    
}