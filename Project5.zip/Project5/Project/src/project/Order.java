package project;
import java.util.Scanner;
public class Order{
  public Scanner read = new Scanner(System.in);
  
  private String name;
  private String ID;
  private String PhoneNum;
  private String email;
  public static Address[] addressA = new Address[5];
  private Address address ;
  

  public Order(String name, String ID, String PhoneNum, String email, Address address){
        this.name = name;
        this.ID = ID;
        this.PhoneNum = PhoneNum;
        this.email = email; 
        this.address = address;
    }

    public Order() {
        
    }

  public String getName() {
        return name;
    }
    public void setName(String name ) {
        this.name = name;
    }
    public Address getAddress(){
        return address;
    }
    public String getID() {
        return ID;
    }
    public void setID(String ID ) {
        this.ID = ID;
    }
  public String getPhoneNum() {
        return PhoneNum;
    }
  public void setPhoneNum(String PhoneNum ) {
        this.PhoneNum =PhoneNum;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

   
  public void takeInfo(){
      System.out.println("\u001B[35m" + "************* Customer information **************" + "\u001B[35m" );
    System.out.print("Enter your name: ");
      setName(read.next());
      
    System.out.print("Enter your ID: ");
      setID(read.next());
      
    System.out.print("Enter your Phone Number: ");
      setPhoneNum(read.next());
      
    System.out.print("Enter your Email: ");
      setEmail(read.next());    
  }
  
  @Override
  public String toString(){
      System.out.println("\u001B[35m" + "************* Order detail **************" +  "\033[0m" );
 
     return  "Customer Name: "+ getName() +"\nCustomer ID : "+ getID() +"\nCustomer Number : "+ getPhoneNum() +"\nCustomer Email : "+ getEmail() + getAddress();
        
  }

    /*@Override
    public String toString() {
        return "\u001B[45m" + "************* Order detail **************" + "\u001B[45m" + "\nOrder{" + "read=" + read + ", name=" + name + ", ID=" + ID + ", PhoneNum=" + PhoneNum + ", email=" + email + ", address=" + address + '}';
    }*/
  
  
  
  
}