package project;
public abstract class Product implements Payable{
    
    private final static  String Brand = "2w1";
   
    public Product() {
        
    }

    public String getBrand() {
        return Brand;
    }

    public abstract void choice();

    @Override
    public String toString() {
        return "Product{" + "Brand=" + Brand + '}';
    }
  
     
}
