package project;
import java.util.Scanner;
public class Eyeliner extends Eye {
   
    public Scanner read = new Scanner(System.in);
    private double price ;
    private String type ;
   private int choice ;
    private int number ;

    public int getChoice() {
        return choice;
    }

    public int getNumber() {
        return number;
    }
  
    public Eyeliner() {
       
    }
    
    

    public Eyeliner(double price, String type) {
        
        this.price = price;
        this.type = type;
    }
    
    @Override
public void choice(){
        
    
     System.out.println("\u001B[35m" + "************** Eyeliner **************" +"\033[0m");
        System.out.println(
                 "1: Epic smoke Liner 41.25 SAR " 
                + "\n2: Epic INK Liner 37.50 SAR "
                + "\n3: Slim Eye Pencil 18.75 SAR "
                + "\n4: Jumbo Eye Pencil 20.63 SAR"
                + "\n5: Super Skinny Eye Marker 37.50 SAR");
                System.out.println("\u001B[35m" + "Please choose the type of Eyeliner you want: " +"\033[0m");
         do{
         choice = read.nextInt();
         if(choice != 1 && choice != 2 && choice != 3 && choice != 4 && choice != 5 )
              System.out.println("\u001B[31m"+"invalid input please try again\n" +  "select 1 to 5" +"\033[0m" );
        }while(choice != 1 && choice != 2 && choice != 3 && choice != 4 && choice != 5 );
      
        System.out.println("\u001B[35m" + "please enter how many product would you like to add:" + "\u001B[42m"+"\033[0m");
         number = read.nextInt();
        // price = cost(choice , number);
        }

    public double getPrice() {
        return price;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    
    

    @Override
    public double cost() {
        choice();
        switch(choice){
            case 1 : price = 41.25 * number ;
                    setType("Epic smoke Liner")  ; break;
            case 2 : price = 37.50 * number ;
                    setType("Epic INK Liner")  ; break;
            case 3 : price = 18.75 * number ;
                    setType("Slim Eye Pencil")  ; break;
            case 4 : price = 20.63 * number ;
                    setType("Jumbo Eye Pencil")  ; break;
            case 5 : price = 37.50 * number ; 
                    setType("Super Skinny Eye Marker")  ; break;
            default: 
                price = 0;
       }        
        return price = price + (price*Payable.TAX);  
}

   @Override
    public String toString() {
      return  "type = " + getType() + "\nprice = " + getPrice() + " SAR";   
    }
   
              
    
}