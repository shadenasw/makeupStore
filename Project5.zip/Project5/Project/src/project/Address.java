package project;
import java.util.Scanner;
public class Address {
   private String city ;
   private String houseNom;
   private String street;
public Scanner read = new Scanner(System.in);

    public Address(String city, String houseNom, String street) {
        this.city = city;
        this.houseNom = houseNom;
        this.street = street;
    }

    public Address() {
    }
    

    public String getCity() {
        return city;
    }

    public String getHouseNom() {
        return houseNom;
    }

    public String getStreet() {
        return street;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setHouseNom(String houseNom) {
        this.houseNom = houseNom;
    }

    public void setStreet(String street) {
        this.street = street;
    }
    public void takeAddressInfo(){
        System.out.print("Enter your City: ");
                setCity(read.next());
        System.out.print("Enter your house number: ");
                setHouseNom(read.next());
        System.out.println("Enter Street name: ");
                setStreet(read.next());
    }

    @Override
    public String toString() {
        return  "\ncity : " + city + "\nhouseNom : " + houseNom + "\nstreet : " + street ;
    }
    
   
}