package project;
import java.util.Scanner;
public class EyeBrushes extends Brush {
    public Scanner input = new Scanner(System.in);

    private double cost ;
    private String type;
    private int choice ;
    private int number ;

    public int getChoice() {
        return choice;
    }

    public int getNumber() {
        return number;
    }

    public EyeBrushes(double cost, String type) {
        this.cost = cost;
        this.type = type;
    }
    
    public EyeBrushes() {
        
    }
  
    @Override
    public void choice() {

         System.out.println("\u001B[35m" + "************** Eye Brushes **************" +"\033[0m");
        System.out.println("1- EyeShadow Blending Brush\n"
                + "2- Pro Angled Eyeliner Brush\n"
                + "3- Eye Smuduing Brush  \n"
                + "4- Dual-Ended Brow Brush \n"
                + "5- Pro Flat Detail Brush");
        System.out.println("\u001B[35m" +"Enter The number of The Brush type you Choice" +"\033[0m");
           do{
         choice = input.nextInt();
         if(choice != 1 && choice != 2 && choice != 3 && choice != 4 && choice != 5 )
              System.out.println("\u001B[31m"+"invalid input please try again\n" +  "select 1 to 5" +"\033[0m" );
        }while(choice != 1 && choice != 2 && choice != 3 && choice != 4 && choice != 5 );
           System.out.println("Enter number you want:" );
         number = input.nextInt();
      
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    

    @Override
    public double cost(  ) {
        choice();
        switch (choice) {
            case 1:
                cost = 40;
                setType("EyeShadow Blending Brush");
                break;

            case 2:
                cost = 33;
                setType("Pro Angled Eyeliner Brush");
                break;
            case 3:
                cost = 40;
                setType("Eye Smuduing Brush");
                break;
            case 4:
                cost = 44;
                setType("Dual-Ended Brow Brush");
                break;
            case 5:
                cost = 36;
                setType("Pro Flat Detail Brush");
                break;
            default:
                 System.out.println("This Item is not Available");
        }
       return cost = cost + (cost*Payable.TAX);  

    }
    @Override
    public String toString( ){
       
        return  "type = " + getType() + "\nprice = " + getCost() + " SAR";
                                                                                                                          
    }

}
