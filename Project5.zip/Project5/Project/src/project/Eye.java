package project;
public abstract class Eye extends Product{

    public Eye() {
    
    }

    @Override
    public String toString() {
        return "Eye{" + '}';
    }
    
    
  
}