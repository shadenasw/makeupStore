package project;
public abstract class Lip extends Product {

   private String color;
   private String coverage;

    public Lip( String color,String coverage) {
       
        this.color= color;
        this.coverage= coverage;
    }

    public Lip() {
     
    }

    @Override
    public String toString() {
        return "Lip{" + "color=" + color + ", coverage=" + coverage + '}';
    }
    

  
    
   

  
    
}