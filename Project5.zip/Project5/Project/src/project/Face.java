package project;
public abstract class Face extends Product{
 
    public Face() {
        
    }



 public abstract void selectColor();

    @Override
    public String toString() {
        return "Face{" + '}';
    }

  
}