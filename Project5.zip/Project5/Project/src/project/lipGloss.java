package project;
import java.util.Scanner;
public class lipGloss extends Lip {
    
    Scanner input = new Scanner(System.in);
   
    
    private double cost ;
    private String type;
    private int choice ;
    private int number ;

    public int getChoice() {
        return choice;
    }

    public int getNumber() {
        return number;
    }
    public lipGloss( String color, String coverage) {
        super(color, coverage);
    }

    public lipGloss(){
    }
    
    
   

    @Override
    public void choice() {
        
         System.out.println("\u001B[35m" + "************** Lip Gloss **************" +"\033[0m");
        System.out.println("1- MILKY GLOSS , 48.75 SAR"
                + "\n2- BUTTER GLOSS , 22.50 SAR"
                + "\n3- LINGERIE GLOSS , 126.50 SAR"
                + "\n4- FILLER INSTINCT PLUMPING LIP POLISH, 151.75 SAR");
          System.out.println("\u001B[35m" +"Enter The number of type you Choice" +"\033[0m");
           do{
         choice = input.nextInt();
         if(choice != 1 && choice != 2 && choice != 3 && choice != 4  )
              System.out.println("\u001B[31m"+"invalid input please try again\n" +  "select 1 to 5" +"\033[0m" );
        }while(choice != 1 && choice != 2 && choice != 3 && choice != 4  );
           System.out.println("Enter number you want:" );
         number = input.nextInt();
        
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
      @Override
    public double cost() {
        choice();
        switch (choice) {
            case 1:
                cost = 48.75* number;
                setType("MILKY GLOSS");
                break;

            case 2:
                cost = 22.50* number;
                 setType("BUTTER GLOSS");
                break;
            case 3:
                cost=126.50* number;
                 setType("LINGERIE GLOSS");
                break;
            case 4:
                cost=151.75* number; 
                 setType("FILLER INSTINCT PLUMPING LIP POLISH");
                break;
         
            default:
                 System.out.println("This Item is not Available");
        }
        return cost = cost + (cost*Payable.TAX);  
        
    }
 @Override
    public String toString( ){
        
        return  "type = " + getType() + "\nprice = " + getCost() + " SAR";
                                                                                                                          
    }
  
}