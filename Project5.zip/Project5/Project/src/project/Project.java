package project;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.InputMismatchException;
public class Project{
    public static Scanner read = new Scanner(System.in);
     public static double totPrice =0;
     public static int index = 0;
     public static boolean orders = true;
     public static Order info[] = new Order[3];
    public static void main(String[] args){
    
       ArrayList<Payable> ml = new ArrayList<Payable>();
        while(orders != false){ 
        FillList(ml); 
            System.out.println("Do you want to make another order?\nAnswer must be Yes or No");
            String answer = read.next();
            if(answer.equals("Yes"))
                orders = true;
            else if(answer.equals("No"))
                orders = false;
            else {
                System.out.println("Wrong answer");
            break;
            }
        }
        //Fiels
       TextFileWrite application = new TextFileWrite();
          application.openFile();
          for(Payable i : ml){ 
              application.addRecords(i);}
          application.closeFile();
          
          TextFileRead applicationRead = new TextFileRead();
        applicationRead.openFile();
        applicationRead.readRecords();
        applicationRead.closeFile();

       
    }//End main
    
    public static void FillList(ArrayList<Payable> L ){
        boolean i = true ;
        int choice =0;
     int choiceFace=0 , choiceEye=0 , choiceBrush=0 , choiceLip=0;
          while(i){
              try{
              do{
                  
          menu();
         choice = read.nextInt();
        switch(choice){
            case 1 :{System.out.println("Enter your choice\n1-Foundation \n2-Blush");
                     choiceFace =read.nextInt();
                     switch(choiceFace){
                  case 1 : Payable Foundation = new Foundation();
                      L.add(Foundation); 
                      totPrice += Foundation.cost();
                  break;
                  case 2 : Payable Blush = new Blush();
                      L.add(Blush); 
                    totPrice +=  Blush.cost();
                  break; 
                  default: System.out.println("\u001B[31m"+"Invalid input." +"\033[0m"); }}break;
            case 2 :{System.out.println("Enter your choice\n1-EyeLiner \n2-Eyeshadow");
                     choiceEye =read.nextInt();
                   switch(choiceEye){
                  case 1 : Payable Eyeliner = new Eyeliner();
                      L.add(Eyeliner); 
                      totPrice += Eyeliner.cost();
                                   break;
                  case 2 : Payable Eyeshadow = new Eyeshadow();
                      L.add(Eyeshadow); 
                    totPrice +=  Eyeshadow.cost();
                  break;
                    default: System.out.println("\u001B[31m"+"Invalid input." +"\033[0m");}} break;
            case 3 :{System.out.println("Enter your choice\n1-Eye Brushes \n2-Face Brushes");
                     choiceBrush =read.nextInt();
                     switch(choiceBrush){
                  case 1 : Payable EyeBrushes = new EyeBrushes();
                      L.add(EyeBrushes); 
                    totPrice +=  EyeBrushes.cost();
                  break; 
                  case 2 : Payable FaceBrushes = new FaceBrushes();
                      L.add(FaceBrushes); 
                      totPrice += FaceBrushes.cost(); break;
                      default: System.out.println("\u001B[31m"+"Invalid input." +"\033[0m");}}break; 
            case 4 :{System.out.println("Enter your choice\n1-Lip Gloss \n2-Lip Stick");
                     choiceLip =read.nextInt();
                     switch(choiceLip){
                  case 1 : Payable lipGloss = new lipGloss();
                      L.add(lipGloss); 
                     totPrice += lipGloss.cost(); break;
                  case 2 : Payable lipStick = new lipStick();
                      L.add(lipStick); 
                    totPrice +=  lipStick.cost();
                  break; 
                      default: System.out.println("\u001B[31m"+"Invalid input." +"\033[0m");}}break;
            case 5 : System.out.println("\u001B[35m" + "************* Shopping basket **************" + "\u001B[35m" ); break;
            default : System.out.println("\u001B[31m"+"Enter number between 1-4 or 5 to stop" +"\033[0m");
        }//End switch
               
       }while(choice != 5);
              DisplayList(L);
                i = false;
              }catch(InputMismatchException a){
                  System.out.println("\u001B[31m"+"Enter an \"Integer\" number plz.. try again"+"\033[0m");
                  read.next();
         }
          }}
    
    
    
    public static void DisplayList(ArrayList<Payable> L ){
      
          takeInfo();
          for (Payable i : L) {
              System.out.println(i);
                }
          if(totPrice >1000){
              System.out.println("\u001B[32m" + "Congratulations, you got a 20% discount." + "\033[0m");
          totPrice = totPrice - (totPrice*0.20);}
          System.out.println("\u001B[35m" + "Total price = " + "\033[0m" + totPrice + " SAR" ); 
          System.out.println("\u001B[35m" + "order submitted successfully...Thank you for shopping " +"\033[0m");
    }
          
    public static void menu(){
    System.out.println("\u001B[35m" + "\t2W1 Makeup store \t"+ "\u001B[30m");
    System.out.println("\u001B[35m" + "PRODUCTS LIST"+ "\u001B[30m");
    System.out.println("\u001B[35m" + "************** **************" + "\u001B[30m");
    System.out.println( " 1.FACEPRODUCT \n 2.EYE PRODUCT \n 3.BRUSHES \n 4.LIP PRODUCT \n 5.Checkout");
    System.out.println("\u001B[35m" + "************** **************" +"\033[0m");
    System.out.print("\u001B[35m" + ">>>" +"\033[0m"); 
    }
    
    public static void takeInfo(){
        System.out.println("\u001B[35m" + "************* Customer information **************" + "\u001B[35m" );
    System.out.print("Enter your name: ");
      String name = read.next();
      
    System.out.print("Enter your ID: ");
      String ID = read.next();
    System.out.print("Enter your Phone Number: ");
      String phoneNum = read.next();
    System.out.print("Enter your Email: ");
      String email = read.next();    
    System.out.print("Enter your City: ");
      String city = read.next();
    System.out.print("Enter your house number: ");
      String houseNum = read.next();
    System.out.println("Enter Street name: ");
      String street= read.next();
      Order o = new Order(name , ID , phoneNum , email , new Address(city , houseNum , street));
        
        System.out.println(o.toString());
      try{
      info[index] = o;
      index++;
      }
      catch(ArrayIndexOutOfBoundsException e){
          System.out.println("\u001B[31m"+"SORRY..You cant order more than 3 Orders " +"\033[0m");
            orders = false;
            System.exit(0);
      }
       
    }
    
}

