package project;
import java.util.Scanner;

public class Foundation extends Face {
    public Scanner input = new Scanner(System.in);
    
   private String color ;
   private double price =0;
   private String type;
   private int choice ;
   private int number ;

    public int getChoice() {
        return choice;
    }

    public int getNumber() {
        return number;
    }
    public Foundation() {
       
    }

    public Foundation(String color, double price, String type){
        
        this.color = color;
        this.price = price;
        this.type = type;
    }
  

    public String getColor() {
        return color;
    }

    public double getPrice() {
        return price;
    }

    public String getType() {
        return type;
    }
    

    public void setColor(String color) {
        this.color = color;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setType(String type) {
        this.type = type;
    }
 
  
        @Override
    public void choice() {
    
        System.out.println("\u001B[35m" + "************** Foundation**************" +"\033[0m");
                  System.out.println("FIND FOUNDATIONS IN INCLUSIVE SHADES, FINISHES, AND FORMULAS. ");
        System.out.println("__________________________________________________");
        System.out.println(" 1. Full Coverage Foundation 56.25\n 2. Adjustable Liquid Foundation 52.5  ");
         do{
         choice = input.nextInt();
         if(choice != 1 && choice != 2)
              System.out.println("\u001B[31m"+"invalid input please try again\n" +  "select 1 or 2" +"\033[0m" );
        }while(choice != 1 && choice != 2);
        selectColor();
        System.out.print("\u001B[35m" + "please enter how many product would you like to add:" + "\u001B[42m"+"\033[0m");
        number = input.nextInt();
      //  price += cost(choice , number);
        System.out.println("__________________________________________________");
        
      
    }

    

    @Override
    public void selectColor() {
        
        boolean i = true ;
        System.out.println("\u001B[35m" + "Select Color " + "\u001B[42m"+"\033[0m");
        System.out.println("01 Light \n02 Vanila \n03 Beige \n04 Golden");
        while(i){
        
            int num = input.nextInt();
        switch (num) {
            case 01:
                setColor("Light"); i = false;
                break; 

            case 02:
                setColor("Vanila");i = false;
                break;

            case 03:
                setColor("Beige");i = false;

                break;
            case 04:
                setColor("Golden");i = false;
                break;
            default:  
                System.out.println("invalid input please try again\n" + "\u001B[31m"+ "select from 1 to 4" +"\033[0m" );
                
        } 
        }
            
    }

    @Override
    public double cost() {
       choice();
        switch (choice) {
            case 1: 
                price = 56.25*number;
              setType("Full Coverage Foundation");  
                break;
             case 2:
                 price = 52.50*number;
              setType("Adjustable Liquid Foundation"); 
                break;     
             default:      
                price = 0;    
              
        }
      return price = price +(price*Payable.TAX);
    }

    @Override
    public String toString() {
        
      return "type = " + getType() +"\nColor = " + getColor() + "\nprice = " + getPrice() + " SAR";   
    }
}