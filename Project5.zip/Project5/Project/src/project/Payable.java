package project;
public interface Payable  {
                   
    public static final double TAX = 0.15;
    public abstract double cost();
}
