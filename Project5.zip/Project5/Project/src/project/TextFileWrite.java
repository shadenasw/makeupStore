package project;

import java.io.FileNotFoundException;
import java.util.Formatter;
import java.util.FormatterClosedException;

public class TextFileWrite {

    private Formatter output;

    public void openFile() {
        try {
            output = new Formatter("Project.txt");
        } catch (SecurityException a) {
            System.err.println("You dont have access to write.");
            System.exit(1);
        } catch (FileNotFoundException s) {
            System.err.println("Error opening or creating File.");
            System.exit(1);
        }
    }

    public void addRecords(Payable A) {
        try {
            output.format(A.toString());// to write in the file
            output.format("\n");
        } catch (FormatterClosedException a) {
            System.err.println("Error writing to file.");

        }
    }

    public void closeFile() {
        if (output != null) {
            output.close();
        }
    }

}
